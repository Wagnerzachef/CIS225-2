import java.util.ArrayList;
import java.util.Random;
/**
 * Maganges customers and there purchases.
 *
 * @author Zachary Wagner
 * @version 2-3-2023
 */
public class Manager
{
    private ArrayList<Customer> customers;
    private ArrayList<Website> websites;

    /**
     * Constructor for objects of class Manager
     */
    public Manager()
    {
        customers = new ArrayList<Customer>();
        websites = new ArrayList<Website>();
    }

    /**
     * Add a customer
     *
     * @param  all of the fields that make up the customer class minus
     * customer number.
     */
    public void addCustomer(String companyZip, String customerFirstName, String customerLastName, String companyName, String companyStreet, String companyCity, String companyState, String customerPhoneNumber)
    {
        String customerNumber = generateCustomerNumber();
        while(validateCustomer(customerNumber) != true) {
            customerNumber = generateCustomerNumber();
        }
        customers.add(new Customer(customerPhoneNumber, companyZip, customerNumber, customerFirstName, customerLastName, companyName, companyStreet, companyCity, companyState));
    }
    
    public void addWebsite(String customerNumber, String websiteName, String websiteDesign, boolean feature1, boolean feature2, boolean feature3, boolean feature4, boolean feature5)
    {
        websites.add(new Website(customerNumber, websiteName, websiteDesign, feature1, feature2, feature3, feature4, feature5));
    }
    
    public void printCustomerBill(String customerNumber)
    {
        int totalBill = calculateCustomerPrice(customerNumber);
        System.out.println("The total bill for customer #" + customerNumber +" is: $" + totalBill);
    }
    
    private int calculateCustomerPrice(String customerNumber)
    {
        int totalBill = 0;
        for (Website website : websites)
        {
            if (website.getCustomerNumber() == customerNumber)
            {
                totalBill += website.calculatePrice();
            }
        }
        return totalBill;
    }
    
    /**
     * Generate a random five digit customer number.
     * 
     */
    private String generateCustomerNumber()
    {
        int[] numbers = new int[5];
        String customerNumber;
        Random wackado = new Random();
        numbers[0] = wackado.nextInt(9);
        numbers[1] = wackado.nextInt(9);
        numbers[2] = wackado.nextInt(9);
        numbers[3] = wackado.nextInt(9);
        numbers[4] = wackado.nextInt(9);
        StringBuilder builder = new StringBuilder(); 
        for(int number : numbers) {
            builder.append(number);
        }
        customerNumber = builder.toString(); 
        return customerNumber;
    }
    
    /**
     * Check if the customer exists.
     */
    private boolean validateCustomer(String customerNumber)
    {
        for(Customer customer : customers) {
            if(customer.getCustomerNumber() == customerNumber) {
                return false;
            }
        }
        return true;
    }
}
