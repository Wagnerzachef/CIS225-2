
/**
 * Class to store customer information.
 *
 * @author Zachary Wagner
 * @version 2-3-2023
 */
public class Customer
{
    // instance variables - replace the example below with your own
    private String companyZip;
    private String customerPhoneNumber;
    private String customerFirstName;
    private String customerLastName;
    private String companyName;
    private String companyStreet;
    private String companyCity;
    private String companyState;
    private String customerNumber;

    /**
     * Constructor for objects of class Customer
     */
    public Customer(String customerNumber, String customerPhoneNumber, String customerFirstName, String customerLastName, String companyName, String companyStreet, String companyCity, String companyState, String companyZip)
    {
        this.customerPhoneNumber = customerPhoneNumber;
        this.customerFirstName = customerFirstName;
        this.customerLastName = customerLastName;
        this.companyName = companyName;
        this.companyStreet = companyStreet;
        this.companyCity = companyCity;
        this.companyState = companyState;
        this.companyZip = companyZip;
        this.customerNumber = customerNumber;
    }
    
    public void setCustomerNumber(String customerNumber)
    {
        this.customerNumber = customerNumber;
    }

    public void setCompanyZip(String companyZip)
    {
        this.companyZip = companyZip;
    }
    
    public void setCustomerPhoneNumber(String customerPhoneNumber)
    {
        this.customerPhoneNumber = customerPhoneNumber;
    }
    
    public void setCustomerLastName(String customerLastName)
    {
        this.customerLastName = customerLastName;
    }
    
    public void setCustomerFirstName(String customerFirstName)
    {
        this.customerFirstName = customerFirstName;
    }
    
    public void setCompanyName(String companyName)
    {
        this.companyName = companyName;
    }
    
    public void setCompanyStreet(String companyStreet)
    {
        this.companyStreet = companyStreet;
    }
    
    public void setCompanyCity(String companyCity)
    {
        this.companyCity = companyCity;
    }
    
    public void setCompanyState(String companyState)
    {
        this.companyState = companyState;
    }
    
    public String getCompanyZip()
   {
       return companyZip;
   }
   
   public String getCustomerPhoneNumber()
   {
       return customerPhoneNumber;
   }
   
   public String getCustomerFirstName()
   {
       return customerFirstName;
   }
   
   public String getCustomerLastName()
   {
       return customerLastName;
   }
   
   public String getCompanyName()
   {
       return companyName;
   }
   
   public String getCompanyStreet()
   {
       return companyStreet;
   }
   
   public String getCompanyCity()
   {
       return companyCity;
   }
   
   public String getCompanyState()
   {
       return companyState;
   }
   
   public String getCustomerNumber()
   {
       return customerNumber;
   }
}
