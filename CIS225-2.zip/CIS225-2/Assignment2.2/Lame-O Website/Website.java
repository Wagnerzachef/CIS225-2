
/**
 * A class to act as a base for a website.
 *
 * @author Zachary Wagner
 * @version 2-3-2023
 */
public class Website
{
    // instance variables - replace the example below with your own
    private String customerNumber;
    private String websiteName;
    private String websiteDesign;
    private boolean feature1;
    private boolean feature2;
    private boolean feature3;
    private boolean feature4;
    private boolean feature5;
    private int nature = 300, nf1 = 10, nf2 = 15, nf3 = 20, nf4 = 25, nf5 = 30;
    private int tech = 350, tf1 = 20, tf2 = 30, tf3 = 40, tf4 = 50, tf5 = 60;
    private int business = 375, bf1 = 30, bf2 = 40, bf3 = 50, bf4 = 60, bf5 = 70;
    private int music = 400, mf1 = 85, mf2 = 95, mf3 = 110, mf4 = 130, mf5 = 210;
    private int naughty = 500, pf1 = 100, pf2 = 200, pf3 = 300, pf4 = 400, pf5 = 500;

    /**
     * Constructor for objects of class Website
     */
    public Website(String customerNumber, String websiteName, String websiteDesign, boolean feature1, boolean feature2, boolean feature3, boolean feature4, boolean feature5)
    {
        this.customerNumber = customerNumber;
        this.websiteName = websiteName;
        this.websiteDesign = websiteDesign;
        this.feature1 = feature1;
        this.feature2 = feature2;
        this.feature3 = feature3;
        this.feature4 = feature4;
        this.feature5 = feature5;
    }

    /**
     * Calculate the price of the end website.
     *
     * @return    the final bill
     */
    public int calculatePrice()
    {
        int bill = 0;
        if(websiteDesign == "nature") {
            bill += nature;
            if(feature1) {
                bill += nf1;
            }
            if(feature2) {
                bill += nf2;
            }
            if(feature3) {
                bill += nf3;
            }
            if(feature4) {
                bill += nf4;
            }
            if(feature5) {
                bill += nf5;
            }
        }
        else if(websiteDesign == "tech") {
            bill += tech;
            if(feature1) {
                bill += tf1;
            }
            if(feature2) {
                bill += tf2;
            }
            if(feature3) {
                bill += tf3;
            }
            if(feature4) {
                bill += tf4;
            }
            if(feature5) {
                bill += tf5;
            }
        }
        else if(websiteDesign == "business") {
            bill += business;
            if(feature1) {
                bill += bf1;
            }
            if(feature2) {
                bill += bf2;
            }
            if(feature3) {
                bill += bf3;
            }
            if(feature4) {
                bill += bf4;
            }
            if(feature5) {
                bill += bf5;
            }
        }
        else if(websiteDesign == "music") {
            bill += music;
            if(feature1) {
                bill += mf1;
            }
            if(feature2) {
                bill += mf2;
            }
            if(feature3) {
                bill += mf3;
            }
            if(feature4) {
                bill += mf4;
            }
            if(feature5) {
                bill += mf5;
            }
        }
        else if(websiteDesign == "naughty") {
            bill += naughty;
            if(feature1) {
                bill += pf1;
            }
            if(feature2) {
                bill += pf2;
            }
            if(feature3) {
                bill += pf3;
            }
            if(feature4) {
                bill += pf4;
            }
            if(feature5) {
                bill += pf5;
            }
        }
        return bill;
    }
    
    public void setCustomerPNumber(String cusomerNumber)
    {
        this.customerNumber = customerNumber;
    }
    
    public void setWebsiteName(String websiteName)
    {
        this.websiteName = websiteName;
    }
    
    public void setWebsiteDesign(String websiteDesign)
    {
        this.websiteDesign = websiteDesign;
    }
    
    public void setFeature1(boolean feature1)
    {
        this.feature1 = feature1;
    }
    
    public void setFeature2(boolean feature2)
    {
        this.feature2 = feature2;
    }
    
    public void setFeature3(boolean feature3)
    {
        this.feature3 = feature3;
    }
    
    public void setFeature4(boolean feature4)
    {
        this.feature4 = feature4;
    }
    
    public void setFeature5(boolean feature5)
    {
        this.feature5 = feature5;
    }
    
    public String getCustomerNumber()
    {
        return customerNumber;
    }
    
    public String getWebsiteName()
    {
        return websiteName;
    }
    
    public String getWebsiteDesign()
    {
        return websiteDesign;
    }
    
    public boolean getFeature1()
    {
        return feature1;
    }
    
    public boolean getFeature2()
    {
        return feature2;
    }
    
    public boolean getFeature3()
    {
        return feature3;
    }
    
    public boolean getFeature4()
    {
        return feature4;
    }
    
    public boolean getFeature5()
    {
        return feature5;
    }
}
