
/**
 * Class to check the book objects that a user chooses .
 *
 * @Zachary Wagner
 * @version 1.5
 */
public class Information
{
    /**
     *
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void printBookInformation(Book book)
    {
        printTitle(book);
        printAuthorLastName(book);
        printAuthorFirstName(book);
        printDatePublished(book);
        printISBNNumber(book);
        printPages(book);
    }
    /**
     * Search through the given book object for the title and print it out.
     */
    public void printTitle(Book book)
    {
        String title = book.getTitle();
        System.out.println("Title: " + title);
    }
    /**
     * Search through the given book for the last name of the author
     * and print it out.
     */
    public void printAuthorLastName(Book book)
    {
        String lastName = book.getAuthorLastName();
        System.out.println("Author Last Name: " + lastName);
    }
    /**
     * Search through the given book for the First name of the author
     * and print it out.
     */
    public void printAuthorFirstName(Book book)
    {
        String firstName = book.getAuthorFirstName();
        System.out.println("Author First Name: " + firstName);
    }
    /**
     * Search through the given book for the day it was published
     * and print it out.
     */
    public void printDatePublished(Book book)
    {
        String published = book.getDatePublished();
        System.out.println("Date Published: " + published);
    }
    /**
     * Search through the given book for the ISBN number
     * and print it out.
     */
    public void printISBNNumber(Book book)
    {
        double iSBN = book.getISBNNumber();
        System.out.println("ISBN Number: " + iSBN);
    }
    /**
     * Search through the given book for the last name of the author
     * and print it out.
     */
    public void printPages(Book book)
    {
        int pageNumber = book.getPages();
        System.out.println("Number of Pages: " + pageNumber);
    }
    
}
