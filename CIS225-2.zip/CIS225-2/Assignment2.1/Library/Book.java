
/**
 * The template for all of the books.
 *
 * @Zachary Wagner
 * @1.28.2023
 */
public class Book
{
    // instance variables - replace the example below with your own
    private String authorLastName;
    private String authorFirstName;
    private double isbnNumber;
    private String title;
    private String datePublished;
    private int pages;

    /**
     * Constructor for objects of class Book
     */
    public Book(String authorLastName, String authorFirstName, double ispnNumber,
    String title, String datePublished, int pages)
    {
        this.authorLastName = authorLastName;
        this.authorFirstName = authorFirstName;
        this.isbnNumber = isbnNumber;
        this.title = title;
        this.datePublished = datePublished;
        if(pages >= 10) {
            this.pages = pages;
        }
        else {
            System.out.println("ERROR: The minimum number of pages a book can have is: 10");
        }
    }

    /**
     * Gets the authors last name.
     */
    public String getAuthorLastName()
    {
        return authorLastName;
    }
    /**
     * Gets thre authors first name.
     */
    public String getAuthorFirstName()
    {
        return authorFirstName;
    }
    /**
     * Get the title of the book.
     */
    public String getTitle()
    {
        return title;
    }
    /**
     * Get the ISBN number.
     */
    public double getISBNNumber()
    {
        return isbnNumber;
    }
    /**
     * Get the books publication date.
     */
    public String getDatePublished()
    {
        return datePublished;
    }
    /**
     * A method to check the amount of pages.
     *
     */
    public int getPages()
    {
        return pages;
    }
}
