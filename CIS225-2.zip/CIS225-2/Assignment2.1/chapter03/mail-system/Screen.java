
/**
 * Make a screen
 *
 * zacharywagner
 * 1-27-2023
 */
public class Screen
{
    // instance variables - replace the example below with your own
    private int xRes;
    private int yRes;
    private int screen;

    /**
     * Constructor for objects of class Screen
     */
    public Screen(int xRes, int yRes)
    {
        // initialise instance variables
        this.xRes = xRes;
        this.yRes = yRes;
        screen = xRes * yRes;
    }

    /**
     * Set the screen size
     *
     * 
     */
    public int numberOfPixels()
    {
        return screen;
    }
    public void clear(boolean invert)
    {
    Screen screen = new Screen(1024, 768); 
    if(screen.numberOfPixels() > 2000000) {
         screen.clear(true);
    } 
    }
}
